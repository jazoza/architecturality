class TwitterAuth:
    # arhitekturality credentials to access Twitter API 'architects_keywords'
    	consumer_key="j9XuNxy1qClcxN5FZuVwE9qgB"
    	consumer_secret="7sFzdgCgoqwOjcYaVTfGT8rZrmG5OQSrYsX7LAChLaol8q2c7L"

    	access_token="867399552105684992-xahSnksJ7skTecaOby3eFDSlx6BzrD8"
    	access_token_secret="tzXf2S4501SWEuDOx3q4pEtrCeMrwbYAKWy0YEgHHCBy9"
