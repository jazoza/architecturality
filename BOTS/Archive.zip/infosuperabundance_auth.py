class TwitterAuth:
    # arhitekturality credentials to access Twitter API 'architects_keywords'
    	consumer_key="cvFOJU9ZXh1lyHBTyQSBDnmPP"
    	consumer_secret="MH7LEY8sKwovVln633ThWW6mSvfyWXoxcrn0wCryIooyAA5LFS"

    	access_token="869662890244149256-7zJZ9Ky8tFsk06t8X7m2GiMA7uguzhc"
    	access_token_secret="HIDsUAzVB8RVWWSjVALV43Xp6Y9qrYEnXs3AZUFlT1a75"
