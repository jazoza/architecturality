class TwitterAuth:
    # arhitekturality credentials to access Twitter API 'architects_keywords'
    	consumer_key="DCemcYn2MfePCVYF2TVSaXFBr"
    	consumer_secret="ZcYAjHRoHDQ91OWy2zObdVBWnvtGIWgBG9YPknRPCYXLkMxT2R"

    	access_token="867352935516319745-l0sSlFjzF3sg5QAZedukLCyDZ6CI75V"
    	access_token_secret="omI0zI45SqqXUuk9r0WYyirgGx1iC1IoxkM7BksKd9Vuy"
