class TwitterAuth:
    # arhitekturality credentials to access Twitter API 'architects_keywords'
    	consumer_key="bl8co63k26JyEhqN8DUYRefuj"
    	consumer_secret="eneEWvEiXguW9zFlNH8oZX6hHfDHSeIejCue6T29a3xbH0J0ET"

    	access_token="883705042452320256-Zds5rezNetG3Q8Bem7zDciurPfte4aS"
    	access_token_secret="m67fkx67yto0sqg3AzTKCcnwJev38piw82p5sH0ZfMsQA"
