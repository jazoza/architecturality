class TwitterAuth:
    # arhitekturality credentials to access Twitter API 'architects_keywords'
    	consumer_key="z8RIaKjgcgkpabKxT6BJ3pxsD"
    	consumer_secret="edgy1zJCyb9S5QyxTEb4G7f59ZPi8h9qv0lQHGVJrqu4YkuhCr"

    	access_token="870594459234381828-ZH3COqlFh1pGW1p8Okwqi7aRG7kZxwb"
    	access_token_secret="8hndmFImsuh9LOlSvJlpXVMfL3HNWQgLY0mSEGlbiMY1W"
