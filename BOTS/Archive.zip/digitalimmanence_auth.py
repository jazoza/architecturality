class TwitterAuth:
    # arhitekturality credentials to access Twitter API 'architects_keywords'
    	consumer_key="kkQHRBpX1DJbrw1AH15fHfKR9"
    	consumer_secret="qHXXSxaAgAZcIl5WAOlFLYbtyWACRfSPnzzZtqSTDYTFqJqHuS"

    	access_token="883693573593595904-a9XGmChw9cUtrZeWYY70BjcMzSJW3Sz"
    	access_token_secret="x31peXhqqiO8O1ys2JEhtgfbnNMuhWz2HvNTajrNqi7HV"
